/*
 * tempo_1ms.c
 *
 *  Created on: 25 de nov. de 2025
 *      Author: POIAN
 */


