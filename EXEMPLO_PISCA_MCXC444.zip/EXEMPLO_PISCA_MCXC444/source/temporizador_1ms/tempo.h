/*
 * tempo.h
 *
 *  Created on: 25 de nov. de 2025
 *      Author: POIAN
 */

#ifndef TEMPORIZADOR_1MS_TEMPO_H_
#define TEMPORIZADOR_1MS_TEMPO_H_



#endif /* TEMPORIZADOR_1MS_TEMPO_H_ */
