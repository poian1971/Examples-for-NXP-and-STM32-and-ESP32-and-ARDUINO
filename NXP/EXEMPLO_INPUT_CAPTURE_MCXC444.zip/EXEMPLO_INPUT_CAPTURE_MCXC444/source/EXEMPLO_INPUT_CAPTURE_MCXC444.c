/*
 * Copyright 2016-2025 NXP
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

/**
 * @file    EXEMPLO_INPUT_CAPTURE_MCXC444.c
 * @brief   Application entry point.
 */

// Arquivos de configuração/abstração da própria NXP (gerados pelo MCUXpresso/config tools).
#include "board.h"          // Configurações específicas da placa (pins, LEDs, UART default, etc.).
#include "peripherals.h"    // Inicialização dos periféricos gerados pela ferramenta.
#include "pin_mux.h"        // Multiplexação de pinos (funções alternativas GPIO/TPM/UART...).

// Drivers da NXP para clock, comuns e debug.
#include "fsl_debug_console.h"  // Interface de console serial (PRINTF, scanf, etc.).

// Drivers de periféricos NXP usados no projeto.
#include "fsl_tpm.h"        // Timer TPM – usado para captura de pulsos de rádio.

/* TODO: insert other include files here. */

/* TODO: insert other definitions and declarations here. */

// Quantidade máxima de amostras de pulsos que serão armazenadas por frame.
// Cada amostra corresponde a um intervalo entre bordas (largura) + nível correspondente
#define NUM_SAMPLES 150

// Flag que indica se o sistema está pronto para começar a aceitar/gravar um frame de rádio.
// É modificada apenas pela ISR do TPM (captura de pulsos).
volatile bool pronto_para_aceitar = false;

// Buffer para armazenar as larguras dos pulsos (em microsegundos).
// Cada posição corresponde a um intervalo entre duas bordas capturadas.
volatile uint16_t pulseWidthBuffer[NUM_SAMPLES];

// Buffer para armazenar o nível lógico associado à largura de cada pulso (0 = baixo, 1 = alto).
volatile uint8_t  pulseLevelBuffer[NUM_SAMPLES];

// Índice atual de escrita no buffer de pulsos (0..NUM_SAMPLES-1).
volatile uint8_t sampleIndex = 0;

// Flag que indica para o main() que há um conjunto completo de amostras pronto para ser processado.
// Setado na ISR do TPM quando sampleIndex atinge NUM_SAMPLES.
volatile uint8_t samplesReady = 0;

// Armazena o último timestamp (em ticks do TPM) usado para calcular deltas entre bordas.
volatile uint32_t lastCapture = 0;

// Armazena o nível lógico do sinal no intervalo entre a última borda e a borda atual.
// Usado para saber se a largura calculada é de um período em nível alto ou baixo.
volatile uint8_t lastLevel = 0;

// ============================================================
//   TPM0 IRQ — CAPTURADOR DE PULSOS
// ============================================================
void TPM0_IRQHandler(void)
{
    // Verifica se a interrupção do TPM0 foi causada pelo canal 0 (CH0).
    // O TPM pode gerar IRQ por overflow, outros canais, etc.
    if (TPM_GetStatusFlags(TPM0) & kTPM_Chnl0Flag)
    {
        // Lê o valor capturado no registrador CnV do canal 0.
        // Esse valor é o "timestamp" (contador do TPM) no momento exato da borda.
        uint32_t cap = TPM0->CONTROLS[0].CnV;

        // Flag local estática para identificar a primeira borda capturada após iniciar.
        // static => mantém valor entre chamadas da IRQ.
        static uint8_t firstCapture = 1;

        // ===== TRATAMENTO DA PRIMEIRA BORDA =====
        if (firstCapture)
        {
            // Lê o nível atual do pino PTC1 (após a borda acontecer).
            // Observação: PTC1 é o pino associado ao TPM0_CH0 na sua configuração.
            uint8_t pinState = GPIO_PinRead(GPIOC, 1);

            // Define lastLevel como o nível que existia ANTES da borda.
            // Se após a borda ficou 0, antes era 1; se após ficou 1, antes era 0.
            lastLevel = !pinState;

            // Salva o timestamp dessa primeira borda como referência para a próxima.
            lastCapture = cap;

            // Marca que a primeira captura já foi processada.
            firstCapture = 0;

            // Limpa o flag do canal 0 no TPM.
            // Se não limpar, a interrupção pode disparar novamente imediatamente.
            TPM_ClearStatusFlags(TPM0, kTPM_Chnl0Flag);

            // Retorna sem calcular largura de pulso.
            // A largura só faz sentido a partir da segunda borda (quando existe delta).
            return;
        }

        // ===== DAQUI PRA BAIXO: LÓGICA NORMAL (2ª BORDA EM DIANTE) =====

        // Lê o estado atual do pino PTC1 logo após a borda.
        // Se estiver 1: significa que a borda foi de subida (0->1).
        // Se estiver 0: significa que a borda foi de descida (1->0).
        uint8_t pinState = GPIO_PinRead(GPIOC, 1);  // PTC1 = TPM0_CH0

        // Variável para armazenar a quantidade de ticks entre a borda atual e a anterior.
        uint32_t ticks;

        // Calcula o delta entre cap (timestamp atual) e lastCapture (timestamp anterior).
        // Se cap >= lastCapture: não houve overflow do contador.
        if (cap >= lastCapture)
        {
            // Delta simples quando não há overflow.
            ticks = cap - lastCapture;
        }
        else
        {
            // Caso cap < lastCapture: houve overflow do contador de 16 bits (0xFFFF->0).
            // Fórmula: (resto até 0xFFFF) + (cap) + 1 (conta a virada do contador).
            ticks = (0xFFFF - lastCapture) + cap + 1;
        }

        // Converte ticks para microsegundos (aproximação inteira).
        // Premissas:
        // - clock do TPM: 48 MHz
        // - prescaler: /16 => frequência do contador = 3 MHz
        // - período do tick ~ 0,333 us
        //
        // width_us ≈ ticks * 0,333 => ticks * 333 / 1000
        uint16_t width_us = (ticks * 333) / 1000;

        // Se ainda não estamos prontos para aceitar/capturar um frame...
        if (!pronto_para_aceitar)
        {
            // Procura o "pulso ativador" (sync/header) para iniciar a captura do frame.
            // Critérios:
            // - largura entre 11 ms e 12 ms
            // - lastLevel == 0 => significa que o nível anterior (medido) era BAIXO
            if (width_us >= 9000 && width_us <= 11000 && lastLevel == 0)
            {
                // Encontrou header/sync -> começa a gravar os pulsos subsequentes.
                pronto_para_aceitar = true;

                // Salva esse pulso gatilho como primeira amostra do buffer.
                pulseWidthBuffer[0] = width_us;     // largura do pulso (us)
                pulseLevelBuffer[0] = lastLevel;    // nível desse pulso (0=baixo, 1=alto)

                // Próxima amostra vai no índice 1.
                sampleIndex = 1;
            }
        }
        else
        {
            // Já estamos em modo de captura: grava a largura e o nível do pulso atual.
            pulseWidthBuffer[sampleIndex] = width_us;   // armazena duração do nível anterior
            pulseLevelBuffer[sampleIndex] = lastLevel;  // armazena qual era esse nível

            // Avança para a próxima posição do buffer.
            sampleIndex++;

            // Se o buffer encheu, sinaliza para o main() que há um bloco pronto.
            if (sampleIndex >= NUM_SAMPLES)
            {
                // Flag consumida no loop principal (main) para decodificar o frame.
                samplesReady = 1;

                // Reseta o índice para próxima captura.
                sampleIndex = 0;

                // Sai do modo de captura (captura apenas um lote/frame por vez).
                pronto_para_aceitar = false;
            }
        }

        // Atualiza lastLevel para o próximo intervalo:
        // Após esta borda, o sinal ficou em pinState; então o "próximo pulso" terá esse nível.
        lastLevel = pinState;

        // Atualiza lastCapture para a próxima medição de delta (ticks).
        lastCapture = cap;

        // Limpa o flag do canal 0 para permitir novas interrupções.
        TPM_ClearStatusFlags(TPM0, kTPM_Chnl0Flag);
    }
}

/*
 * Rotina principal
 */
int main(void)
{

    /* Init board hardware. */
    BOARD_InitBootPins();
    BOARD_InitBootClocks();
    BOARD_InitBootPeripherals();
#ifndef BOARD_INIT_DEBUG_CONSOLE_PERIPHERAL
    /* Init FSL debug console. */
    BOARD_InitDebugConsole();
#endif

    while(1)
    {
        if (samplesReady)
        {
            samplesReady = 0;

            PRINTF("\r\n======= LOTE DE 150 AMOSTRAS =======\r\n");

            for (uint8_t i = 0; i < NUM_SAMPLES; i++)
            {
                if (pulseLevelBuffer[i])
                {
                    PRINTF("ALTO  – largura = %u us\r\n", pulseWidthBuffer[i]);
                }
                else
                {
                    PRINTF("BAIXO – largura = %u us\r\n", pulseWidthBuffer[i]);
                }
            }

            PRINTF("===================================\r\n");
        }
    }
}


