/*
 * Copyright 2016-2025 NXP
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

/**
 * @file    EXEMPLO_INPUT_CAPTURE_MCXC444.c
 * @brief   Application entry point.
 */
#include <stdio.h>
#include "board.h"
#include "peripherals.h"
#include "pin_mux.h"
#include "clock_config.h"
#include "fsl_debug_console.h"
#include "fsl_tpm.h"
/* TODO: insert other include files here. */

/* TODO: insert other definitions and declarations here. */
#define NUM_SAMPLES 10

volatile uint16_t pulseWidthBuffer[NUM_SAMPLES];
volatile uint8_t  pulseLevelBuffer[NUM_SAMPLES];

volatile uint8_t sampleIndex = 0;
volatile uint8_t samplesReady = 0;

volatile uint32_t lastCapture = 0;

volatile uint8_t mostra_resultados = 1;

void TPM0_IRQHandler(void)
{
    /*
     * Verifica se o motivo da interrupção foi o canal 0 do TPM.
     * O TPM pode ter vários tipos de flags (overflow, outros canais, etc),
     * então sempre checamos se o flag específico do canal 0 (kTPM_Chnl0Flag)
     * está ativo antes de processar.
     */
    if (TPM_GetStatusFlags(TPM0) & kTPM_Chnl0Flag)
    {
        /*
         * Lê o valor capturado no registrador CnV do canal 0.
         * Esse valor é o "timestamp" (em ticks do timer) no exato momento
         * em que a borda (subida ou descida) foi detectada.
         */
        uint32_t cap = TPM0->CONTROLS[0].CnV;

        /*
         * firstCapture é usado para ignorar a PRIMEIRA borda.
         * Por quê?
         * - No início do programa, lastCapture começa em 0.
         * - Se na primeira borda fizéssemos: width = cap - lastCapture,
         *   o resultado seria apenas o tempo desde que o timer começou,
         *   e não a largura real de um pulso.
         * Então:
         * - Na primeira IRQ, só guardamos cap em lastCapture e saímos.
         * - A partir da segunda borda, passamos a medir larguras reais.
         *
         * "static" é fundamental aqui:
         * - A variável mantém o valor entre chamadas da interrupção.
         * - Se não fosse static, ela voltaria a 1 toda vez,
         *   e você nunca sairia do bloco de "primeira captura".
         */
        static uint8_t firstCapture = 1;

        /* ===== TRATAMENTO DA PRIMEIRA BORDA ===== */
        if (firstCapture)
        {
            // Guarda o timestamp da primeira borda como referência inicial
            lastCapture = cap;

            // Marca que a primeira captura já foi tratada
            firstCapture = 0;

            // Limpa o flag da interrupção do canal 0.
            // Se não limpar, o TPM vai chamar a IRQ de novo imediatamente.
            TPM_ClearStatusFlags(TPM0, kTPM_Chnl0Flag);

            // Sai da interrupção SEM calcular largura de pulso.
            // A partir da próxima borda, entra na parte "normal" da IRQ.
            return;
        }

        /* ===== DAQUI PRA BAIXO: LÓGICA NORMAL (2ª BORDA EM DIANTE) ===== */

        /*
         * Lê o estado atual do pino do canal (PTC1).
         * Isso indica o nível que o sinal assumiu DEPOIS da borda:
         *  - Se o pino está em nível alto (1), a borda foi de SUBIDA.
         *  - Se o pino está em nível baixo (0), a borda foi de DESCIDA.
         *
         * Assim conseguimos saber se estamos medindo:
         *  - largura de pulso ALTO, ou
         *  - largura de pulso BAIXO.
         */
        uint8_t pinState = GPIO_PinRead(GPIOC, 1);  // PTC1 = TPM0_CH0

        uint32_t ticks;

        /*
         * Calcula a diferença entre o timestamp atual (cap)
         * e o timestamp anterior (lastCapture), tratando também
         * o caso em que o contador do TPM deu overflow.
         *
         * Caso normal (sem overflow):
         *   cap >= lastCapture  → width = cap - lastCapture
         *
         * Caso com overflow:
         *   o contador passou de 0xFFFF e voltou a 0 entre uma borda e outra.
         *   Então fazemos:
         *     ticks = (0xFFFF - lastCapture) + cap + 1
         *   que é a "volta" completa que o contador deu.
         */
        if (cap >= lastCapture)
        {
            ticks = cap - lastCapture;
        }
        else
        {
            ticks = (0xFFFF - lastCapture) + cap + 1;
        }

        /*
         * Converte de ticks para microsegundos.
         *
         * Aqui estamos assumindo:
         *   - Clock do TPM = 48 MHz
         *   - Prescaler do TPM = divide por 16
         *
         * Logo:
         *   frequência do contador = 48 MHz / 16 = 3 MHz
         *   período de 1 tick      = 1 / 3 MHz ≈ 0,333 µs
         *
         * Para converter:
         *   us ≈ ticks * 0,333
         *
         * Como não usamos float na interrupção, aproximamos:
         *   us ≈ (ticks * 333) / 1000
         */
        uint16_t width_us = (ticks * 333) / 1000;

        /*
         * Armazena a largura medida e o nível do sinal
         * no buffer de amostras, na posição "sampleIndex".
         * - pulseWidthBuffer[] guarda o tempo em µs.
         * - pulseLevelBuffer[] guarda se era nível alto (1) ou baixo (0).
         */
        pulseWidthBuffer[sampleIndex] = width_us;
        pulseLevelBuffer[sampleIndex] = pinState;

        /*
         * Avança o índice do buffer.
         * Quando chegamos em NUM_SAMPLES, significa que
         * coletamos um "lote" completo de amostras.
         */
        sampleIndex++;
        if (sampleIndex >= NUM_SAMPLES)
        {
            // Sinaliza para a main que o lote está pronto para processamento
            samplesReady = 1;

            // Reinicia o índice para começar a preencher o próximo lote
            sampleIndex = 0;
        }

        // Atualiza o timestamp da última borda para a próxima medição
        lastCapture = cap;

        /*
         * Limpa o flag da interrupção do canal 0.
         * Isso é OBRIGATÓRIO para permitir que futuras bordas
         * gerem novas interrupções.
         * Se não limpar aqui, o TPM pode ficar chamando a IRQ sem parar.
         */
        TPM_ClearStatusFlags(TPM0, kTPM_Chnl0Flag);
    }
}

/*
 * Rotina principal
 */
int main(void)
{

    /* Init board hardware. */
    BOARD_InitBootPins();
    BOARD_InitBootClocks();
    BOARD_InitBootPeripherals();
#ifndef BOARD_INIT_DEBUG_CONSOLE_PERIPHERAL
    /* Init FSL debug console. */
    BOARD_InitDebugConsole();
#endif

    while(1)
    {
        if (samplesReady && mostra_resultados)
        {
            mostra_resultados = 0;

            PRINTF("\r\n======= LOTE DE 10 AMOSTRAS =======\r\n");

            for (uint8_t i = 0; i < NUM_SAMPLES; i++)
            {
                if (pulseLevelBuffer[i])
                {
                    PRINTF("ALTO  – largura = %u us\r\n", pulseWidthBuffer[i]);
                }
                else
                {
                    PRINTF("BAIXO – largura = %u us\r\n", pulseWidthBuffer[i]);
                }
            }

            PRINTF("===================================\r\n");
        }
    }
}


